namespace ContosoUniversity.Models.SchoolViewModels
{
#region snippet
    public class CourseViewModel
    {
        public int CourseID { get; set; }
        public string Title { get; set; }
        public int Credits { get; set; }
        public string DepartmentName { get; set; }
    }
#endregion
}